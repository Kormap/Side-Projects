### `kospeech`

<img src="https://user-images.githubusercontent.com/42150335/83944090-d8ad6300-a83b-11ea-8a2c-2f0d9ba0e54d.png" width=700>   
  
`kospeech` module has modularized and extensible components for las models, trainer, evaluator, checkpoints etc...   
In addition, `kospeech` enables learning in a variety of environments with a simple option setting.  